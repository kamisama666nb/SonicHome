package tv.sonic.home;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(7, 10, 16);
    private final int panel = Color.rgb(17, 23, 33);
    private final int white = Color.rgb(239, 243, 248);
    private final int muted = Color.rgb(142, 154, 171);
    private final int accent = Color.rgb(190, 211, 233);
    private LinearLayout root;
    private LinearLayout appRow;
    private final List<AppEntry> apps = new ArrayList<>();

    static class AppEntry {
        String label; String pkg; Intent launch; android.graphics.drawable.Drawable icon;
        AppEntry(String l, String p, Intent i, android.graphics.drawable.Drawable d) { label=l; pkg=p; launch=i; icon=d; }
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildShell(); loadApps();
    }

    private void buildShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(48), dp(28), dp(48), dp(24)); root.setBackgroundColor(bg);
        setContentView(root);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL);
        TextView brand = text("SONIC HOME", 15, white, true); brand.setLetterSpacing(.16f);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView clock = text(DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date()), 14, muted, false); top.addView(clock);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(34)));
        TextView heading = text("Everything,\nin its place.", 36, white, true); heading.setLineSpacing(dp(1), 1f);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2); hp.topMargin = dp(34); root.addView(heading, hp);
        TextView sub = text("YOUR TV  ·  SIMPLE BY DESIGN", 11, muted, true); sub.setLetterSpacing(.12f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin=dp(12); root.addView(sub, sp);
        TextView section = text("APPS", 12, muted, true); section.setLetterSpacing(.18f);
        LinearLayout.LayoutParams secp = new LinearLayout.LayoutParams(-1,-2); secp.topMargin=dp(35); root.addView(section,secp);
        HorizontalScrollView hsv = new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); hsv.setClipToPadding(false);
        appRow = new LinearLayout(this); appRow.setOrientation(LinearLayout.HORIZONTAL); appRow.setPadding(dp(2),dp(14),dp(2),dp(14)); hsv.addView(appRow);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, 0, 1); rp.topMargin=dp(2); root.addView(hsv,rp);
        LinearLayout footer = new LinearLayout(this); footer.setGravity(Gravity.CENTER_VERTICAL); footer.setOrientation(LinearLayout.HORIZONTAL);
        TextView hint=text("OK  Open     MENU  Options     BACK  Exit app",11,muted,false); footer.addView(hint,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings=text("SETTINGS  ↗",11,accent,true); settings.setPadding(dp(16),dp(10),dp(16),dp(10)); settings.setFocusable(true); settings.setBackground(round(panel,dp(10),Color.TRANSPARENT)); settings.setOnClickListener(v->showSettings()); footer.addView(settings);
        root.addView(footer,new LinearLayout.LayoutParams(-1,dp(48)));
    }

    private void loadApps() {
        apps.clear(); PackageManager pm=getPackageManager(); Intent query=new Intent(Intent.ACTION_MAIN,null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found=pm.queryIntentActivities(query,0);
        for(ResolveInfo ri:found) {
            String pkg=ri.activityInfo.packageName;
            if(pkg.equals(getPackageName())) continue;
            Intent launch=new Intent(Intent.ACTION_MAIN); launch.addCategory(Intent.CATEGORY_LAUNCHER); launch.setClassName(pkg,ri.activityInfo.name); launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { apps.add(new AppEntry(ri.loadLabel(pm).toString(),pkg,launch,ri.loadIcon(pm))); } catch(Exception ignored) {}
        }
        Collections.sort(apps, Comparator.comparing(a->a.label.toLowerCase()));
        appRow.removeAllViews();
        if(apps.isEmpty()) { TextView empty=text("No launchable apps found",16,muted,false); appRow.addView(empty); return; }
        for(AppEntry a:apps) {
            LinearLayout tile=new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER); tile.setFocusable(true); tile.setFocusableInTouchMode(true); tile.setClickable(true); tile.setPadding(dp(8),dp(12),dp(8),dp(10));
            GradientDrawable normal=round(panel,dp(14),Color.TRANSPARENT); tile.setBackground(normal);
            ImageView icon=new ImageView(this); icon.setImageDrawable(a.icon); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(54),dp(54)); ip.gravity=Gravity.CENTER; tile.addView(icon,ip);
            TextView label=text(a.label,12,white,false); label.setGravity(Gravity.CENTER); label.setMaxLines(2); label.setPadding(0,dp(10),0,0); tile.addView(label,new LinearLayout.LayoutParams(dp(104),dp(36)));
            tile.setOnFocusChangeListener((v,focus)->{ v.setBackground(round(focus?Color.rgb(31,43,59):panel,dp(14),focus?accent:Color.TRANSPARENT)); v.setScaleX(focus?1.045f:1f); v.setScaleY(focus?1.045f:1f); });
            tile.setOnClickListener(v->{ try { startActivity(a.launch); } catch(ActivityNotFoundException e) { Toast.makeText(this,"App could not be opened",Toast.LENGTH_SHORT).show(); } });
            tile.setOnLongClickListener(v->{ new AlertDialog.Builder(this).setTitle(a.label).setItems(new String[]{"Open app","App info","Uninstall"},(d,which)->{ if(which==0) tile.performClick(); else if(which==1) openAppInfo(a.pkg); else uninstall(a.pkg); }).show(); return true; });
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(120),dp(124)); tp.rightMargin=dp(10); appRow.addView(tile,tp);
        }
        appRow.getChildAt(0).requestFocus();
    }

    private void showSettings() {
        String[] options={"System settings","Network settings","Display settings","Refresh app list","Wallpaper settings","About Sonic Home"};
        new AlertDialog.Builder(this).setTitle("Sonic Home").setItems(options,(d,w)->{
            if(w==0) safeSettings(Settings.ACTION_SETTINGS);
            else if(w==1) safeSettings(Settings.ACTION_WIRELESS_SETTINGS);
            else if(w==2) safeSettings(Settings.ACTION_DISPLAY_SETTINGS);
            else if(w==3) loadApps();
            else if(w==4) { try { startActivity(new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)); } catch(Exception e) { safeSettings(Settings.ACTION_SETTINGS); } }
            else new AlertDialog.Builder(this).setTitle("Sonic Home · 0.1.0 alpha").setMessage("A lightweight Android TV launcher prototype. Core app navigation is implemented; feature parity and device testing remain in progress.").setPositiveButton("OK",null).show();
        }).show();
    }
    private void safeSettings(String action) { try { startActivity(new Intent(action)); } catch(Exception e) { Toast.makeText(this,"This settings page is not available on this TV",Toast.LENGTH_SHORT).show(); } }
    private void openAppInfo(String pkg) { try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+pkg))); } catch(Exception ignored) {} }
    private void uninstall(String pkg) { try { startActivity(new Intent(Intent.ACTION_DELETE,android.net.Uri.parse("package:"+pkg))); } catch(Exception ignored) {} }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode==KeyEvent.KEYCODE_MENU || keyCode==KeyEvent.KEYCODE_SETTINGS) { showSettings(); return true; }
        return super.onKeyDown(keyCode,event);
    }
    private TextView text(String s,float size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(bold?Typeface.create("sans-serif-medium",Typeface.NORMAL):Typeface.create("sans-serif",Typeface.NORMAL)); return t; }
    private GradientDrawable round(int color,int radius,int stroke) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); if(stroke!=Color.TRANSPARENT) d.setStroke(dp(1),stroke); return d; }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+.5f); }
}
